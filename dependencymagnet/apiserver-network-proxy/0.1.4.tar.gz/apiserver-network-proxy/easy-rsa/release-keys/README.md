Easy-RSA 3 release GPG keys
===

This document contains the GPG Key IDs used to sign official releases starting
with the 3.x series. These release-keys are available on public keyserver
mirrors, such as pgp.mit.edu.

Current keys
---

These keys are currently valid:

* Key ID 0x606FD463
  * Owner: Josh Cepek <josh.cepek@usa.net>
  * Key fingerprint: 65FF 3F24 AA08 E882 CB44  4C94 D731 D97A 606F D463

Former keys
---

These keys were once valid but are now expired or revoked:

* None, currently
